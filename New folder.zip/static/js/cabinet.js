// Make the function global
window.f1 = function (id, zakaz) {
  const elem = document.getElementById(id);
  if (elem.innerHTML) {
    elem.innerHTML = '';
  } else {
    elem.innerHTML = zakaz;
  }
};

document.addEventListener('DOMContentLoaded', function () {
  console.log("cabinet.js loaded!");

  // Handle remove favorite product (like)
  document.querySelectorAll('.remove-like').forEach(button => {
    button.addEventListener('click', function () {
      const tovarId = this.dataset.tovar;

      fetch('/tolike/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-CSRFToken': getCookie('csrftoken')
        },
        body: `tovar_id=${tovarId}`
      })
        .then(response => response.json())
        .then(data => {
          if (data.liked === false) {
            const parent = this.closest('.liked-item');
            parent.remove();

            if (document.querySelectorAll('.liked-item').length === 0) {
              document.getElementById('liked-items').innerHTML = "<p>У вас пока нет избранных товаров.</p>";
            }
          }
        });
    });
  });

  // CSRF helper function
  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith(name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }
});

