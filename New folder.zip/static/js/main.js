function toggleMenu() {
  document.getElementById('nav-left').classList.toggle('active');
  document.getElementById('nav-right').classList.toggle('active');
}

// Like toggle handler for all like buttons across the site
document.addEventListener('DOMContentLoaded', () => {
  const likes = document.querySelectorAll('.like');

  likes.forEach(like => {
    like.addEventListener('click', () => toggleLike(like));
  });
});

/**
 * Toggles like state for a product.
 * @param {HTMLElement} el - The like image element clicked.
 */
function toggleLike(el) {
  const productId = el.id;

  fetch(`/tolike/?k1=${productId}`)
    .then(response => response.json())
    .then(data => {
      const white = '/static/img/swhite.png';
      const red = '/static/img/sred.png';
      el.src = data.liked ? red : white;
      el.title = data.liked ? 'Убрать из избранного' : 'Добавить в избранное';
    })
    .catch(error => {
      console.error('Ошибка при добавлении в избранное:', error);
    });
}
