// Toggle order form visibility
let but1 = document.getElementById('but1');
let form1 = document.getElementById('form1');

let visible = false;
function f1() {
    form1.hidden = !visible;
    visible = !visible;
}
if (but1) {
    but1.onclick = f1;
}

// Hold-to-increase/decrease quantity
let interval = null;
let pending = false;
let currentItemId = null;
let currentDirection = null;

// Function to change the quantity in the cart
function changeQuantity(id, direction) {
    fetch(`/cart/edit/${id}/${direction}/`)
        .then(() => {
            pending = true;
        });
}

// Function to update the input field with the new quantity in real-time
function updateQuantityDisplay(id, direction) {
    const inputField = document.querySelector(`#input-count-${id}`);
    if (inputField) {
        let newValue = parseInt(inputField.value) + direction;
        if (newValue < 1) newValue = 1;  // Prevent negative values
        inputField.value = newValue;
    }
}

document.querySelectorAll('.hold-btn').forEach(button => {
    const itemId = button.dataset.id;
    const direction = button.classList.contains('plus') ? 1 : -1;

    // Start changing quantity when the button is pressed
    const startChanging = () => {
        if (currentItemId !== itemId || currentDirection !== direction) {
            currentItemId = itemId;
            currentDirection = direction;
            changeQuantity(itemId, direction);
        }

        updateQuantityDisplay(itemId, direction);
        interval = setInterval(() => {
            changeQuantity(itemId, direction);
            updateQuantityDisplay(itemId, direction);  // Update display in real-time
        }, 150);
    };

    // Stop changing when the button is released
    const stopChanging = () => {
        clearInterval(interval);
        if (pending) {
            setTimeout(() => location.reload(), 300); // slight delay for last fetch
        }
    };

    // Add event listeners for mouse and touch events
    button.addEventListener('mousedown', startChanging);
    button.addEventListener('mouseup', stopChanging);
    button.addEventListener('mouseleave', stopChanging);
    button.addEventListener('touchstart', startChanging);
    button.addEventListener('touchend', stopChanging);
});
