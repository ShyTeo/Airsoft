from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from django.contrib.auth import views as auth_views
from app import views
from app.views import register

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('catalog/<str:cat>/', views.catalog, name='catalog'),
    path('catalog/buy/<str:cat>/<int:itemid>/', views.buy, name='buy'),
    path('cart/', views.cart, name='cart'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/delete/<int:itemid>/', views.delete, name='delete'),
    path('cart/edit/<int:itemid>/<str:num>/', views.edit, name='edit'),
    path('update-cart/<int:item_id>/<int:new_quantity>/', views.update_quantity, name='update_quantity'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('place_order/', views.place_order, name='place_order'),
    path('cabinet/', views.cabinet, name='cabinet'),  # Ensure the cabinet path is defined
    path('favorites/add/<int:product_id>/', views.add_to_favorites, name='add_to_favorites'),
    path('tolike/', views.tolike, name='tolike'),
    path('register/', register, name='register'),
    path('logout/', auth_views.LogoutView.as_view(next_page='index'), name='logout'),
    path('accounts/', include('django.contrib.auth.urls')),  # Handles login/logout views
]

# Serve media files in development mode
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

