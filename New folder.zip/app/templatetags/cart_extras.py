from django import template

register = template.Library()

@register.filter
def sum_total(cart_items):
    return sum(item.count * item.tovar.price for item in cart_items)

@register.filter
def mul(value, arg):
    return value * arg
