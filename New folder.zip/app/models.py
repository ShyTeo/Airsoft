from django.db import models
from django.contrib.auth.models import User

# --- Categories ---
class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# --- Products (Tovar) ---
class Tovar(models.Model):
    name = models.CharField(max_length=50, verbose_name='Название')
    price = models.IntegerField(verbose_name='Цена')
    image = models.FileField(verbose_name='Картинка', upload_to='img/', null=True, blank=True)
    discount = models.IntegerField(verbose_name='Скидка', default=0)
    category = models.ForeignKey(to=Category, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name

    def get_discounted_price(self):
        """Return price after discount (if any)."""
        return int(self.price * (1 - self.discount / 100)) if self.discount else self.price

    def has_discount(self):
        """Convenience method for checking if a discount exists."""
        return self.discount > 0


# --- Likes / Favorites ---
class Like(models.Model):
    user = models.ForeignKey(to=User, on_delete=models.CASCADE)
    tovar = models.ForeignKey(to=Tovar, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['user', 'tovar']  # Each user can like a product only once

    def __str__(self):
        return f"{self.user.username} likes {self.tovar.name}"


# --- Cart ---
class Cart(models.Model):
    tovar = models.ForeignKey(to=Tovar, on_delete=models.CASCADE)
    count = models.IntegerField(verbose_name='Количество', default=1)
    summa = models.DecimalField(max_digits=12, decimal_places=2, verbose_name='Сумма')
    user = models.ForeignKey(to=User, on_delete=models.CASCADE)

    def calc_summa(self):
        return self.count * self.tovar.get_discounted_price()

    def save(self, *args, **kwargs):
        self.summa = self.calc_summa()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.tovar.name} ({self.count} шт.)"


# --- Order status ---
class Status(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# --- Orders ---
class Order(models.Model):
    user = models.ForeignKey(to=User, on_delete=models.CASCADE)
    adres = models.CharField(verbose_name='Адрес', max_length=1000)
    email = models.EmailField(verbose_name='Email')
    tel = models.CharField(verbose_name='Телефон', max_length=15)
    tovars = models.ManyToManyField(to=Tovar)
    status = models.ForeignKey(to=Status, on_delete=models.SET_NULL, null=True, blank=True)
    total = models.DecimalField(max_digits=12, decimal_places=2, verbose_name='Итог', null=True, blank=True)
    date = models.DateTimeField(verbose_name='Дата', auto_now_add=True, null=True, blank=True)
    zakaz = models.TextField(verbose_name='Заказ')

    def __str__(self):
        return f'{self.date} --- {self.adres}'
