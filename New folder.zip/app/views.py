from datetime import datetime
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.utils import timezone
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.db import models
import telebot

from .models import Tovar, Cart, Order, Status, Like
from .forms import OrderForm

def index(request):
    items = Tovar.objects.all()
    liked = []
    if request.user.is_authenticated:
        liked = Like.objects.filter(user=request.user).values_list('tovar_id', flat=True)
    return render(request, 'index.html', {'items': items, 'liked': liked})

def catalog(request, cat):
    items = Tovar.objects.filter(category__name=cat)
    query = request.GET.get('q')
    if query:
        items = items.filter(
            models.Q(name__icontains=query) |
            models.Q(category__name__icontains=query)
        )
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    if min_price:
        items = items.filter(price__gte=min_price)
    if max_price:
        items = items.filter(price__lte=max_price)
    selected_categories = request.GET.getlist('category')
    if selected_categories:
        items = items.filter(category__name__in=selected_categories)
    sort = request.GET.get('sort')
    if sort == 'price_asc':
        items = items.order_by('price')
    elif sort == 'price_desc':
        items = items.order_by('-price')
    elif sort == 'name_asc':
        items = items.order_by('name')
    elif sort == 'name_desc':
        items = items.order_by('-name')
    liked = []
    if request.user.is_authenticated:
        liked = Like.objects.filter(user=request.user).values_list('tovar_id', flat=True)
    return render(request, 'index.html', {
        'items': items,
        'liked': liked,
        'query': query,
        'min_price': min_price,
        'max_price': max_price,
        'selected_categories': selected_categories,
        'sort': sort,
    })

@login_required
def cart(request):
    user_cart = Cart.objects.filter(user=request.user)
    valid_cart = [item for item in user_cart if hasattr(item, 'tovar') and item.tovar is not None]
    total = sum(item.tovar.price * item.count for item in valid_cart)
    return render(request, 'cart.html', {'cart_items': valid_cart, 'total': total})

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Tovar, id=product_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, tovar=product)
    if not created:
        cart_item.count += 1
    cart_item.summa = cart_item.calc_summa()
    cart_item.save()
    return redirect('cart')

@login_required
def buy(request, cat, itemid):
    item = get_object_or_404(Tovar, id=itemid)
    cart_item, created = Cart.objects.get_or_create(user=request.user, tovar=item)
    if not created:
        cart_item.count += 1
    else:
        cart_item.count = 1
    cart_item.summa = cart_item.calc_summa()
    cart_item.save()
    return redirect('cart')

@login_required
def delete(request, itemid):
    Cart.objects.filter(id=itemid, user=request.user).delete()
    return redirect('cart')

@login_required
def edit(request, itemid, num):
    try:
        item = Cart.objects.get(id=itemid, user=request.user)
        num = int(num)
        item.count += num
        if item.count <= 0:
            item.delete()
        else:
            item.summa = item.calc_summa()
            item.save()
    except Cart.DoesNotExist:
        pass
    return redirect('cart')

@login_required
def update_quantity(request, item_id, new_quantity):
    cart_item = get_object_or_404(Cart, id=item_id, user=request.user)
    try:
        new_count = int(new_quantity)
        if new_count < 1:
            cart_item.delete()
        else:
            cart_item.count = new_count
            cart_item.summa = cart_item.calc_summa()
            cart_item.save()
        return JsonResponse({
            'success': True,
            'new_count': cart_item.count,
            'new_summa': cart_item.summa
        })
    except (ValueError, TypeError):
        return JsonResponse({'success': False, 'message': 'Invalid quantity'})

@login_required
def place_order(request):
    if request.method == 'POST':
        cart_items = Cart.objects.filter(user=request.user)
        if not cart_items:
            return redirect('cart')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        total_price = sum(item.tovar.price * item.count for item in cart_items)
        status = Status.objects.first()
        zakaz_text = '\n'.join([f'{item.tovar.name} x {item.count}' for item in cart_items])
        zakaz_text += f'\nВсего: {total_price} руб\nАдрес: {address}\nТелефон: {phone}\nПользователь: {request.user.username}'
        order = Order.objects.create(
            user=request.user,
            adres=address,
            tel=phone,
            email=email,
            total=total_price,
            date=timezone.now(),
            status=status,
            zakaz=zakaz_text
        )
        for item in cart_items:
            order.tovars.add(item.tovar)
        telegram('Новый заказ!')
        telegram(zakaz_text)
        cart_items.delete()
        return render(request, 'order_success.html', {'order': order})

@login_required
def add_to_favorites(request, product_id):
    product = get_object_or_404(Tovar, id=product_id)
    like_obj, created = Like.objects.get_or_create(user=request.user, tovar=product)
    if not created:
        like_obj.delete()
    else:
        like_obj.save()
    return redirect('cabinet')


@login_required
def tolike(request):
    if request.method == 'POST':
        tovar_id = request.POST.get('k1')  # Get the product ID from the AJAX request
        color = request.POST.get('k2')  # Get the color (used for toggling state)

        # Check if the product exists
        product = get_object_or_404(Tovar, id=tovar_id)

        # Check if the product is already in the user's favorites
        like_obj = Like.objects.filter(user=request.user, tovar=product).first()

        if like_obj:
            # If the product is already in the favorites, remove it (toggle off)
            like_obj.delete()
            return JsonResponse({'liked': False})  # Return that the product was removed from favorites
        else:
            # If it's not in the favorites, add it (toggle on)
            Like.objects.create(user=request.user, tovar=product)
            return JsonResponse({'liked': True})  # Return that the product was added to favorites

    # If the request method is not POST, return a bad request response
    return JsonResponse({'error': 'Invalid request'}, status=400)


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация прошла успешно!')
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})

@login_required
def profile(request):
    return render(request, 'accounts/profile.html')

@login_required
def cabinet(request):
    orders = Order.objects.filter(user=request.user)
    likes = Like.objects.filter(user=request.user)
    return render(request, 'cabinet.html', {'orders': orders, 'likes': likes})

@login_required
def product_detail(request, product_id):
    product = get_object_or_404(Tovar, id=product_id)
    liked = Like.objects.filter(user=request.user, tovar=product).exists()
    return render(request, 'product_detail.html', {'product': product, 'liked': liked})

def telegram(message):
    token = '7475612633:AAFyP-aBT17dpajqiFAUYt92ToEnHGA8ypQ'
    chat_id = '1186459178'
    bot = telebot.TeleBot(token)
    bot.send_message(chat_id, message)
